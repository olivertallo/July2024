using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MedDashboardAPI.Controllers;
using MedDashboardAPI.Data;
using MedDashboardAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;
using System.Linq;
using MedDashboardAPI.Services;
using MedDashboardAPI.Interface.Services;

namespace MedDashboardAPITest
{
    public class PatientsControllerTests
    {
        private readonly Mock<IPatientService> _mockPatientService;
        private readonly PatientsController _controller;

        public PatientsControllerTests()
        {
            _mockPatientService = new Mock<IPatientService>();
            _controller = new PatientsController(_mockPatientService.Object);
        }

        [Fact]
        public async Task Get_ReturnsOkResult_WithListOfPatients()
        {
            // Arrange
            var patients = new List<Patient>
            {
                new Patient { Id = Guid.NewGuid(), FirstName = "Firstname1", LastName = "Lastname1", City = "Cebu City", Active = true },
                new Patient { Id = Guid.NewGuid(), FirstName = "Firstname2", LastName = "Lastname2", City = "Mandaue City", Active = false }
            };
            _mockPatientService.Setup(service => service.GetPatientsAsync()).ReturnsAsync(patients);

            // Act
            var result = await _controller.Get();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnPatients = Assert.IsType<List<Patient>>(okResult.Value);
            Assert.Equal(2, returnPatients.Count);
        }

        [Fact]
        public async Task Add_ReturnsNoContentResult()
        {
            // Arrange
            var newPatient = new PatientData { FirstName = "Firstname3", LastName = "Lastname3", City = "Lapu-lapu City", Active = true };
            _mockPatientService.Setup(service => service.AddPatientAsync(newPatient)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.Add(newPatient);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task Update_ReturnsNoContentResult()
        {
            // Arrange
            var patientId = Guid.NewGuid();
            var updatedPatient = new PatientData { FirstName = "Firstname", LastName = "Lastname", City = "Any City", Active = true };
            _mockPatientService.Setup(service => service.UpdatePatientAsync(patientId, updatedPatient)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.Update(patientId, updatedPatient);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task Delete_ReturnsNoContentResult()
        {
            // Arrange
            var patientId = Guid.NewGuid();
            _mockPatientService.Setup(service => service.DeletePatientAsync(patientId)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.Delete(patientId);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public async Task GetPaged_ReturnsOkResult_WithPagedPatients()
        {
            // Arrange
            var queryParameters = new PatientQueryParameters { City = "Mandaue City" };
            var patients = new List<Patient>
            {
                new Patient { Id = Guid.NewGuid(), FirstName = "Firstname2", LastName = "Lastname2", City = "Mandaue City", Active = false }
            };
            _mockPatientService.Setup(service => service.GetPagedPatientsAsync(queryParameters)).ReturnsAsync(patients);

            // Act
            var result = await _controller.GetPaged(queryParameters);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnPatients = Assert.IsType<List<Patient>>(okResult.Value);
            Assert.Single(returnPatients);
        }
    }
}