﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedDashboardAPI.Data;
using MedDashboardAPI.Interface.Repositories;
using MedDashboardAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace MedDashboardAPI.Repositories
{
    public class PatientRepository : IPatientRepository
    {
        private readonly InMemoryDatabaseContext _dbContext;

        public PatientRepository(InMemoryDatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Patient>> GetPatientsAsync()
        {
            return await _dbContext.Patients.ToListAsync();
        }

        public async Task<Patient> GetPatientByIdAsync(Guid id)
        {
            return await _dbContext.Patients.FindAsync(id);
        }

        public async Task AddPatientAsync(Patient patient)
        {
            await _dbContext.Patients.AddAsync(patient);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdatePatientAsync(Patient patient)
        {
            _dbContext.Patients.Update(patient);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeletePatientAsync(Guid id)
        {
            var patient = await _dbContext.Patients.FindAsync(id);
            if (patient != null)
            {
                _dbContext.Patients.Remove(patient);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
