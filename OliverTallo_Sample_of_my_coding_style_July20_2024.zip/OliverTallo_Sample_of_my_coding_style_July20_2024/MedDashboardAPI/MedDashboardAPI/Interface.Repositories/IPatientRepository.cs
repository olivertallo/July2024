﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MedDashboardAPI.Models;

namespace MedDashboardAPI.Interface.Repositories
{
    public interface IPatientRepository
    {
        Task<IEnumerable<Patient>> GetPatientsAsync();
        Task<Patient> GetPatientByIdAsync(Guid id);
        Task AddPatientAsync(Patient patient);
        Task UpdatePatientAsync(Patient patient);
        Task DeletePatientAsync(Guid id);
    }
}
