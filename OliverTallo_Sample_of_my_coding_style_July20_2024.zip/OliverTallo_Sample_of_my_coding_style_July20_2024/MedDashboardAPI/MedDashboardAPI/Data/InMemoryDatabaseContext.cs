﻿// Data/InMemoryDatabaseContext.cs
using MedDashboardAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace MedDashboardAPI.Data
{
    public class InMemoryDatabaseContext : DbContext
    {
        public InMemoryDatabaseContext(DbContextOptions<InMemoryDatabaseContext> options) : base(options)
        {

        }

        protected override void OnConfiguring (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "InMemoryDb");
        }

        public DbSet<Patient> Patients { get; set; }
    }
}
