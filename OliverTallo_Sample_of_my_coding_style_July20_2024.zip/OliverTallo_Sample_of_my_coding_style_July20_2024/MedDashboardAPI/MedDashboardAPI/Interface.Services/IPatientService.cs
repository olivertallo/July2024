﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MedDashboardAPI.Models;

namespace MedDashboardAPI.Interface.Services
{
    public interface IPatientService
    {
        Task<IEnumerable<Patient>> GetPatientsAsync();
        Task<Patient> GetPatientByIdAsync(Guid id);
        Task AddPatientAsync(PatientData patientData);
        Task UpdatePatientAsync(Guid id, PatientData patientData);
        Task DeletePatientAsync(Guid id);
        Task<IEnumerable<Patient>> GetPagedPatientsAsync(PatientQueryParameters queryParameters);
    }
}
