﻿// Models/Patient.cs
namespace MedDashboardAPI.Models
{
    public class Patient
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; } = String.Empty;
        public string LastName { get; set; } = String.Empty;
        public string City { get; set; } = String.Empty;
        public bool Active { get; set; }
    }
}
