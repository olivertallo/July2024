﻿// Models/PatientQueryParameters.cs
namespace MedDashboardAPI.Models
{
    public class PatientQueryParameters
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? City { get; set; }
        public bool? Active { get; set; }
        public string? SortBy { get; set; }
        public bool SortDesc { get; set; } = false;
    }
}
