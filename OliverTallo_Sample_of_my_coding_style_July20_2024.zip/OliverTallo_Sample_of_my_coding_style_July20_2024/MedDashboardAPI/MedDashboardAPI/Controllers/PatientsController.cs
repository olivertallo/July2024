﻿// Controllers/PatientsController.cs
using MedDashboardAPI.Data;
using MedDashboardAPI.Interface.Services;
using MedDashboardAPI.Models;
using MedDashboardAPI.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace MedDashboardAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientsController : ControllerBase
    {
        private readonly IPatientService _patientService;

        public PatientsController(IPatientService patientService)
        {
            _patientService = patientService;
        }

        /// <summary>
        /// Get all patient's records.
        /// </summary>
        /// <returns>All patient's records.</returns>
        [HttpGet]
        [Route("Get")]
        public async Task<IActionResult> Get()
        {
            try
            {
                var patients = await _patientService.GetPatientsAsync();
                return Ok(patients);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        /// <summary>
        /// Saves a new patient to the in-memory database.
        /// </summary>
        /// <param name="newPatient"></param>
        /// <returns>A task that represents the asynchronous save operation.</returns>
        [HttpPost]
        [Route("Add")]
        public async Task<IActionResult> Add(PatientData newPatient)
        {
            try
            {
                await _patientService.AddPatientAsync(newPatient);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        /// <summary>
        /// Updates an existing patient in the in-memory database.
        /// </summary>
        /// <param name="id">The unique identifier of the patient to be updated.</param>
        /// <param name="updatedPatient">The patient object with updated values.</param>
        /// <returns>A task that represents the asynchronous update operation.</returns>
        [HttpPut]
        [Route("Update")]
        public async Task<IActionResult> Update(Guid id, PatientData updatedPatient)
        {
            try
            {
                await _patientService.UpdatePatientAsync(id, updatedPatient);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        /// <summary>
        /// Deletes a patient's record from the in-memory database by id.
        /// </summary>
        /// <param name="id">The unique identifier of the patient to be deleted.</param>
        /// <returns>A task that represents the asynchronous delete operation.</returns>
        [HttpPut]
        [Route("Delete")]
        public async Task<IActionResult> Delete(Guid id)
        {
            try
            {
                await _patientService.DeletePatientAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        /// <summary>
        /// Retrieves a paged, filtered, and sorted list of patients.
        /// </summary>
        /// <param name="queryParameters">The query parameters for filtering and sorting.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of patients.</returns>
        [HttpGet]
        [Route("GetPaged")]
        public async Task<IActionResult> GetPaged([FromQuery] PatientQueryParameters queryParameters)
        {
            try
            {
                var patients = await _patientService.GetPagedPatientsAsync(queryParameters);
                return Ok(patients);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
