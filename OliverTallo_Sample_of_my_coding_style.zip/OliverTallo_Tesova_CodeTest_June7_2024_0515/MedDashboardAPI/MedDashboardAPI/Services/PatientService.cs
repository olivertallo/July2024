﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedDashboardAPI.Interface.Repositories;
using MedDashboardAPI.Interface.Services;
using MedDashboardAPI.Models;
using MedDashboardAPI.Repositories;
using Microsoft.EntityFrameworkCore;

namespace MedDashboardAPI.Services
{
    public class PatientService : IPatientService
    {
        private readonly IPatientRepository _patientRepository;

        public PatientService(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }

        public async Task<IEnumerable<Patient>> GetPatientsAsync()
        {
            return await _patientRepository.GetPatientsAsync();
        }

        public async Task<Patient> GetPatientByIdAsync(Guid id)
        {
            return await _patientRepository.GetPatientByIdAsync(id);
        }

        public async Task AddPatientAsync(PatientData patientData)
        {
            var patient = new Patient
            {
                Id = Guid.NewGuid(),
                FirstName = patientData.FirstName,
                LastName = patientData.LastName,
                City = patientData.City,
                Active = patientData.Active
            };

            await _patientRepository.AddPatientAsync(patient);
        }

        public async Task UpdatePatientAsync(Guid id, PatientData patientData)
        {
            var patient = await _patientRepository.GetPatientByIdAsync(id);

            if (patient != null)
            {
                patient.FirstName = patientData.FirstName;
                patient.LastName = patientData.LastName;
                patient.City = patientData.City;
                patient.Active = patientData.Active;

                await _patientRepository.UpdatePatientAsync(patient);
            }
        }

        public async Task DeletePatientAsync(Guid id)
        {
            await _patientRepository.DeletePatientAsync(id);
        }

        public async Task<IEnumerable<Patient>> GetPagedPatientsAsync(PatientQueryParameters queryParameters)
        {
            var patients = (await _patientRepository.GetPatientsAsync()).AsQueryable();

            if (!string.IsNullOrEmpty(queryParameters.FirstName))
            {
                patients = patients.Where(p => p.FirstName.Contains(queryParameters.FirstName));
            }

            if (!string.IsNullOrEmpty(queryParameters.LastName))
            {
                patients = patients.Where(p => p.LastName.Contains(queryParameters.LastName));
            }

            if (!string.IsNullOrEmpty(queryParameters.City))
            {
                patients = patients.Where(p => p.City.Contains(queryParameters.City));
            }

            if (queryParameters.Active.HasValue)
            {
                patients = patients.Where(p => p.Active == queryParameters.Active.Value);
            }

            if (!string.IsNullOrEmpty(queryParameters.SortBy))
            {
                patients = queryParameters.SortDesc
                    ? patients.OrderByDescending(p => EF.Property<object>(p, queryParameters.SortBy))
                    : patients.OrderBy(p => EF.Property<object>(p, queryParameters.SortBy));
            }

            return patients.ToList();
        }
    }
}
